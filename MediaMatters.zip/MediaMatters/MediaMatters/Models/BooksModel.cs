﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MediaMatters.Models
{
    public class BooksModel
    {
        public long ISBN { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public string BookTitle { get; set; }
        public string Edition { get; set; }
        public int PublishedYear { get; set; }
        public string Cover { get; set; }
        public string Notes { get; set; }
    }
}