﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MediaMatters.Models
{
    public class BirdsModel
    {
        public string Name { get; set; }
        public string Country { get; set; }
        public string Notes { get; set; }
        public string Photo { get; set; }
    }
}