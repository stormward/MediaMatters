﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediaMatters.Models;

namespace MediaMatters.Controllers
{
    public class AlbumsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult Albums()
        {
            List<AlbumsModel> album = new List<AlbumsModel>();
            album.Add(new AlbumsModel { Cover = "Thriller.jpg", Title = "Thriller", Artist = "Michael Jackson", Notes = "Number 1 Album of All Time" });
            album.Add(new AlbumsModel { Cover = "BackInBlack.jpg", Title = "Back in Black", Artist = "AC/DC", Notes = "Number 2 Album of All Time" });
            album.Add(new AlbumsModel { Cover = "BatOutOfHell.jpg", Title = "Bat Out of Hell", Artist = "Meat Loaf", Notes = "Number 3 Album of All Time" });
            album.Add(new AlbumsModel { Cover = "TheDarkSideOfTheMoon.jpg", Title = "The Dark Side of the Moon", Artist = "Pink FLoyd", Notes = "Number 4 Album of All Time" });
            album.Add(new AlbumsModel { Cover = "Rumours.jpg", Title = "Rumours", Artist = "Fleetwood Mac", Notes = "Number 5 Album of All Time" });
            return View(album);
        }
    }
}