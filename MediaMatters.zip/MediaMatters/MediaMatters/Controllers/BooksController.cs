﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediaMatters.Models;

namespace MediaMatters.Controllers
{
    public class BooksController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult Books()
        {
            List<BooksModel> book = new List<BooksModel>();
            book.Add(new BooksModel { ISBN = 9780062191496, AuthorLastName = "Stephenson", AuthorFirstName = "Neal", BookTitle = "Reamde", Edition = "1st Edition", PublishedYear = 2012, Cover = "Reamde.jpg", Notes = "A great book ranging a wide variety of topics and locations, with excellent characters and stories. Ranges from North America to Asia, and randsomeware to international terrorism. It's a fascinating journey of a novel." });
            book.Add(new BooksModel { ISBN = 9780060512804, AuthorLastName = "Stephenson", AuthorFirstName = "Neal", BookTitle = "Cryptonomicon", Edition = "1st Edition", PublishedYear = 2002, Cover = "Cryptonomicon2.jpg", Notes = "Another great Neal Stephenson Novel, this time following a group of characters playing different roles in WWII, as well as their decendents in a more modern age. Fiction mixed with some of the very true history of the beginning of digital computers and cryptography." });
            book.Add(new BooksModel { ISBN = 9780142180495, AuthorLastName = "Greenberg", AuthorFirstName = "Andy", BookTitle = "This Machine Kills Secrets", Edition = "1st Edition", PublishedYear = 2013, Cover = "ThisMachineKillsSecrets.jpg", Notes = "This Machine Kills Secrets is an excellent non-fiction novel about the history of the cypherpunks, cryptography, and the internet." });
            book.Add(new BooksModel { ISBN = 9780385544405, AuthorLastName = "Greenberg", AuthorFirstName = "Andy", BookTitle = "SandWorm", Edition = "1st Edition", PublishedYear = 2019, Cover = "Sandworm.jpg", Notes = "Andy Greenberg's newest works on modern cybersercurity and international hackers. He tells a nonfiction story in such a compelling manner that it feels like a scifi novel." });
            book.Add(new BooksModel { ISBN = 9780062572233, AuthorLastName = "Gaiman", AuthorFirstName = "Neil", BookTitle = "American Gods", Edition = "1st Edition", PublishedYear = 2017, Cover = "AmericanGods.jpg", Notes = "American Gods is a fun read exploring the idea that everything to ever be worshipped by human kind has become a God. The main character finds himself amongst them as they wage a war against eachother." });
            return View(book);
        }
    }
}