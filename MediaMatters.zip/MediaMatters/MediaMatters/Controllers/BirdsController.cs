﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediaMatters.Models;

namespace MediaMatters.Controllers
{
    public class BirdsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ActionResult Birds()
        {
            List<BirdsModel> bird = new List<BirdsModel>();
            bird.Add(new BirdsModel { Photo = "Shoebill.jpg", Name = "Shoebill", Country = "East African", Notes = "Cool as heck dinosaur-looking bird with giant beak!" });
            bird.Add(new BirdsModel { Photo = "Kiwi.jpg", Name = "Kiwi Bird", Country = "New Zealander", Notes = "Heckin' cool bird that is super round with a long heckin' beak!" });
            bird.Add(new BirdsModel { Photo = "Frogmouth.jpg", Name = "Sri Lanka Frogmouth Bird", Country = "Indian/Sri Lankan", Notes = "A bird that has a wide mouth. Looks like a heckin' frog mouth. Super cute!" });
            bird.Add(new BirdsModel { Photo = "Booby.jpg", Name = "Blue Footed Booby", Country = "South/Central American", Notes = "This bird's legs are blue as heck. And it's named booby, haha!" });
            bird.Add(new BirdsModel { Photo = "CockOfRock.jpg", Name = "Andean Cock of the Rock", Country = "South American", Notes = "Oranger than a heckin' orange, and it has a funny bump on it's face!" });
            return View(bird);
        }
    }
}